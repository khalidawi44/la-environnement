<?php
/**
 * Gabarit d'une page.
 *
 * @package LA_Environnement
 */

if ( ! defined( 'ABSPATH' ) ) exit;

get_header();

while ( have_posts() ) : the_post();

	get_template_part( 'template-parts/entete', 'page', array(
		'titre' => get_the_title(),
		'chapo' => has_excerpt() ? get_the_excerpt() : '',
	) );
	?>
	<article <?php post_class( 'lae-contenu' ); ?>>
		<div class="lae-shell">
			<?php
			the_content();
			wp_link_pages( array( 'before' => '<p class="lae-pagination">', 'after' => '</p>' ) );
			?>
		</div>
	</article>
	<?php
endwhile;

get_footer();
